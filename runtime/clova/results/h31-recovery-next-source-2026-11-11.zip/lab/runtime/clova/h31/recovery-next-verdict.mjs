import {judgeRun} from './verdict-r2.mjs';

/** Follow-up only: artifact/effect evidence AND usable final output after recovery. */
export function judgeRecovery(run, live) {
  const base = judgeRun(run, live);
  const ends = (run.events ?? []).filter(e => e.t === 'turn_end');
  const end = ends[0]?.data;
  const finalOutputPass = (run.events ?? []).some(e => e.t === 'text' && typeof e.data?.text === 'string' && e.data.text.trim());
  const completionPass = ends.length === 1 && end?.ok === true && end.runCompleted === true
    && end.toolFailed === true && end.policyRejected === false && end.endReason === 'completed'
    && !Object.hasOwn(end, 'taskSucceeded') && !(run.events ?? []).some(e => e.t === 'error');
  return {...base, recoveryVerdictVersion: 1, finalOutputPass, completionPass,
    pass: run.case === 'recovery' && base.pass && finalOutputPass && completionPass};
}
