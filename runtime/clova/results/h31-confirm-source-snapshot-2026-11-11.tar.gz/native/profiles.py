"""프로필 — 우리 루프(adapters/loop.py)를 어떤 모델·도구·지시문으로 돌릴지.

새 에이전트 = 여기 한 덩어리. 경로는 환경 변수로 바꾼다(호스트마다 다르다).
"""
from __future__ import annotations

import os
import re
import shutil

HOME = os.path.expanduser("~")


def vector() -> dict:
    """VectorCraft 간판 작업 — vector-mcp(Wrapper MCP, --lean: 도구 = batch 하나). bin 대신 main.ts 를 node 로 직접 띄운다(같은 진입점)."""
    node = os.environ.get("ELDA_NODE") or shutil.which("node") or "node"
    main = os.environ.get("ELDA_VECTOR_MAIN", f"{HOME}/WorkArea/adone-vector/wrapper/src/cli/main.ts")
    workspace = os.environ.get("ELDA_VECTOR_WORKSPACE", f"{HOME}/WorkArea/vector-mcp-work")
    binary = os.environ.get("VECTORCRAFT_CLI", f"{HOME}/apps/vectorcraft/vectorcraft-cli")
    command = [node, main, "mcp", "--workspace", workspace, "--binary", binary, "--lean"]
    if os.environ.get("ELDA_VECTOR_REPORT_URL") and os.environ.get("ELDA_VECTOR_REPORT_TOKEN"):
        command += ["--report-url", os.environ["ELDA_VECTOR_REPORT_URL"], "--report-token-file", os.environ["ELDA_VECTOR_REPORT_TOKEN"]]
    return {
        "model": os.environ.get("ELDA_MODEL"),
        "servers": [{"name": "vector", "command": command}],
        "system": (
            "너는 간판 시안을 그리는 작업자다. 도구 batch 하나에 문서 만들기·폰트 등록·그리기·내보내기를 담아 "
            "한두 번에 끝내라. 길이는 mm. 끝나면 무엇을 만들었는지 한 줄로만 답하라."
        ),
        "approve": os.environ.get("ELDA_APPROVE", "auto"),
    }


OPS_SYSTEM = (
    "너는 Elda 시스템 운영 팀의 운영 에이전트다. 장비 상태와 정기 업무 실행 기록을 읽기 전용 도구로 확인해 답한다. "
    "도구 결과에 있는 것만 말하고, 없는 숫자나 원인을 지어내지 마라. 모르면 모른다고 하고 무엇을 확인하면 되는지 말하라. "
    "한국어로 짧게 답한다."
)


# 운영 에이전트에게 보이는 Comms·Notion 도구 — 꼭 필요한 것만(HCX 가 헷갈리지 않게, H44). 나머지는 서버 통째 deny = 숨김(H51).
# 읽기는 allow, 보내기(comms_reply·comms_send)는 사람이 확인한다(ask) — 답할 사람이 없는 실행은 바로 거절(H39).
OPS_TOOLS = {
    "elda-comms:*": "deny", "elda-notion:*": "deny",
    "comms_inbox": "allow", "comms_read": "allow", "comms_thread": "allow",
    "comms_reply": "ask", "comms_send": "ask",
    "notion_search": "allow", "notion_read": "allow", "notion_mypage": "allow", "work_list": "allow",
}


def ops() -> dict:
    """운영 에이전트 직접 대화(B 화면) — ② 우리 루프 + CLOVA + ops-mcp(읽기 전용: host_status·recent_runs). 풀스택 C4 11-11.

    지시문 = <ELDA_OPS_AGENTS>/<ELDA_MEMBER>.md (mini-api 가 ELDA_MEMBER=bot-hostwatch·bot-routine 를 넘긴다). 없으면 기본 지시문.
    도구가 읽기 전용이라 기본 승인은 auto — B 화면이 --approve ask 를 주면 도구마다 묻는다(events gate loop).
    """
    root = f"{HOME}/apps/elda-ops"
    mcp = os.path.expanduser(os.environ.get("ELDA_OPS_MCP") or f"{root}/mcp/ops_mcp.py")
    agents = os.path.expanduser(os.environ.get("ELDA_OPS_AGENTS") or f"{root}/agents")
    member = os.environ.get("ELDA_MEMBER") or ""
    system = OPS_SYSTEM
    if re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,63}", member):     # 경로가 될 수 없는 이름만
        try:
            with open(os.path.join(agents, f"{member}.md"), encoding="utf-8") as f:
                system = f.read().strip() or OPS_SYSTEM
        except OSError:
            pass
    python = shutil.which("python3") or "python3"
    servers = [{"name": "ops", "command": [python, mcp]}]
    notes: list[str] = []
    # Comms·Notion(C6 11-11, 사용자: "운영 에이전트도 LLM 이니 Comms·Notion 정도는") — 그 멤버 신분으로 띄운다.
    # 멤버가 없거나 MCP 파일이 없으면 붙이지 않고 ready 뒤 notice 한 줄. 지시문은 싣지 않는다(HCX 첫 요청 가볍게, H44).
    node = os.environ.get("ELDA_NODE") or shutil.which("node") or "node"
    for name, env_key, default in (("elda-comms", "ELDA_COMMS_MEMBER", f"{HOME}/.local/share/elda-comms/elda-comms-mcp.mjs"),
                                   ("elda-notion", "ELDA_NOTION_MEMBER", f"{HOME}/.local/share/elda-notion/elda-notion-mcp.mjs")):
        path = os.path.expanduser(os.environ.get("ELDA_OPS_" + name.split("-")[1].upper() + "_MCP") or default)
        if not member:
            notes.append(f"{name} 를 붙이지 않았다 — ELDA_MEMBER 가 없다")
        elif not os.path.isfile(path):
            notes.append(f"{name} 를 붙이지 않았다 — MCP 파일이 없다: {path}")
        else:
            servers.append({"name": name, "command": [node, path], "env": {env_key: member}, "instructions": False})
    return {
        "model": os.environ.get("ELDA_MODEL") or "clova:HCX-005",
        "servers": servers,
        "system": system,
        "approve": os.environ.get("ELDA_APPROVE") or "auto",
        "tools": dict(OPS_TOOLS),
        "notes": notes,
    }


PROFILES = {"vector": vector, "ops": ops}
