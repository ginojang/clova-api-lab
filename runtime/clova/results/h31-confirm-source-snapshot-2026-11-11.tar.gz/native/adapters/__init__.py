"""어댑터 — 서로 다른 에이전트를 **같은 이벤트 모양**으로 정규화한다.

★ 이 패키지의 존재 이유가 CLI 프레임워크의 존재 이유다. claude·codex·codewhale·우리 모델은
  출력 모양이 전부 다른데, **표면(화면·기록·승인)은 하나여야 한다.** 차이는 여기서 흡수한다.
  (에이전트_콘솔_설계.md §4 — 그 설계의 표면이 웹이 아니라 터미널이 된 것뿐이다)

정규화 이벤트 (콘솔 설계 §4.1 과 동일 — 이미 `agent_event.kind` 로 저장되고 있다):

    turn_start   {task?}                     턴 시작
    text         {text|asm, stage?}          모델이 말한 것 (스트리밍 조각)
    tool_call    {tool, input, callId}       도구를 부르려 한다
    tool_result  {tool, callId, ok, output}  도구 결과
    approval     {tool, input, callId}       ★ 사람 승인 요청 (양방향)
    turn_end     {ok, verdict?, ...}         턴 끝
    error        {message}

⚠ `approval` 이 **양방향**인 것이 PTY 와 결정적으로 다르다. 이것 때문에 프레임워크가 필요하다 —
  PTY 는 화면에 글자를 뿌릴 뿐이라 "무엇을 승인하는지" 를 구조적으로 알 수 없다.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Iterator


@dataclass
class Event:
    t: str
    data: dict = field(default_factory=dict)

    def get(self, k: str, default: Any = None) -> Any:
        return self.data.get(k, default)


# 승인 결정 — 프레임워크가 어댑터에게 돌려주는 값.
@dataclass
class Decision:
    allow: bool
    reason: str | None = None
    # 하네스 H48 — allowed · denied · timeout · cancelled · unavailable. None = 옛 호출(allow 로 판단).
    outcome: str | None = None


class Adapter:
    """모든 어댑터의 계약.

    `run()` 은 정규화 이벤트를 **흘려보낸다**(generator). 프레임워크가 그걸 받아
    화면에 그리고, 기록하고, `approval` 이면 사람에게 묻는다.
    """

    id: str = "base"
    title: str = ""
    desc: str = ""

    def run(self, prompt: str, *, cwd: str, approve: Callable[[Event], Decision],
            **opts: Any) -> Iterator[Event]:
        raise NotImplementedError

    # 어댑터가 스스로 쓸 수 있는지 말한다 — 없는 CLI 에 붙지 않게.
    @staticmethod
    def available() -> tuple[bool, str]:
        return True, ""
