"""우리 도구 호출 루프 — 모델이 고른 도구를 **우리가** 실행한다(docs/CLI_프레임워크_설계.md §6).

거인 엔진 어댑터(claude_sdk·claude_cli)는 도구 선택·실행을 그쪽이 하고 우리는 보여 줄 뿐이었다.
이 어댑터는 모델 연결(providers/) + MCP 클라이언트(mcp_client.py)로 루프를 직접 돈다. 그래서
디코더를 바꾸는 일이 연결 하나 추가로 끝나고, 턴·토큰이 기본 기록이 된다.

    한 턴:  모델에 묻는다 → 도구를 부르면 실행해 결과를 돌려준다 → 도구를 안 부를 때까지 반복

승인 — 에이전트 성능별(메모리 feedback_approval_gate_by_agent_capability): 기본(auto)은 거인 모델이면
승인 없이, 로컬·시험 모델이면 도구마다 묻는다. 프로필·옵션으로 always / never.

대화 = 어댑터 하나(--events · 서빙 ③ 은 프로세스 하나). 대화 안에서는 셋을 잇는다(풀스택 S9 11-09):
  · 모델 연결 — 대본은 이어서 내고, API 클라이언트는 다시 만들지 않는다
  · MCP 서버 — 턴마다 새로 띄우면 앞 턴에 그린 문서가 사라진다. 대화가 끝날 때(close · 프로세스 종료) 닫는다
  · 대화 기록 — 잘 끝난 턴만 잇는다(덧붙이기만)
  turn_end.sessionId 로 대화를 가리킨다. 다음 run() 에 resume 이 없거나 다르면 새 대화 — 셋 다 새로.
  turn_end.history(대화 전체)는 무거워서 ELDA_HISTORY=1 일 때만 싣는다. 평소엔 messages = 개수.
  turn_end.endReason = completed · max_turns · denied · stalled · output_limit · token_limit · malformed_tool_use · error
    (+ 두뇌 API 오류면 apiErrorStatus 숫자) — 하네스 규격 H33·H40.
  turn_end 의 결과 넷(H40): runCompleted(루프가 끝까지 돌았나) · policyRejected(승인 거절로 멈췄나) ·
    toolFailed(실패한 도구 결과가 있었나) — taskSucceeded 는 과제를 판정하는 쪽(러너·입구)이 싣는다.
    승인을 거절하면 그 응답의 남은 호출은 실행하지 않고 턴을 멈춘다(denied, ok:false).
  turn_end.costBasis(H42) = list(입구에 단가표가 있다) · unknown. unknown 이면 비용 상한이 듣지 않으니
    토큰 상한(run token_limit · 프로필 token_limit · ELDA_TOKEN_LIMIT · 기본 400000)으로 막는다.
  Claude 가 아닌 두뇌(provider ≠ anthropic)는 도구 인자를 스키마로 먼저 본다(H41) — null→{} · 문자열로 온
    객체·배열을 푼다 · 그래도 틀리면 실행하지 않고 {category, badField, validShape, retryable, sideEffect} 로
    돌려준다. 인자 잘못이 4번 이어지면 malformed_tool_use. 답 없이 출력 상한에서 잘리면 한 번 다시 묻는다.
  빈 답(H49)은 같은 요청으로 한 번, 짧은 재촉으로 한 번 다시 묻고 그래도 비면 stalled.
  두뇌 일시 오류(H20: 429·5xx·연결 끊김)는 도구가 돌기 전에만 턴에 한 번 다시 — Retry-After(60초까지)를 지키고
    retry 줄을 낸다. 오류는 error.apiError(H50 분류)로. tool_result.sideEffect = not_started·completed·unknown(H40).
  usage 네 칸은 늘, 두뇌가 보고하지 않는 칸은 usageUnreported(H5). turn_end.diag{retries, emptyRetries,
    lastFinishReason}(H53). 같은 두뇌·같은 오류로 두 턴 이어 실패하면 notice{code:"brain_unhealthy"}(H52).
  중단(interrupted)은 루프가 아니라 --events 가 낸다(중단된 턴은 turn_end 가 없다).
  한 턴 안 왕복 상한 = run(max_turns) · 프로필 max_turns · ELDA_MAX_TURNS · 기본 12 순.
"""
from __future__ import annotations

import atexit
import json
import os
import sys
import time
import uuid
from typing import Any, Callable, Iterator

from providers import ApiError

from . import Adapter, Decision, Event

MAX_TURNS = 12
MAX_RESULT_CHARS = 20_000      # 모델에 돌려줄 도구 결과의 상한 — 넘으면 자르고 잘랐다고 알린다
MALFORMED_LIMIT = 4           # 고칠 수 없는 인자 잘못이 이만큼 이어지면 malformed_tool_use(H41)
RETRY_MAX_WAIT = 60.0          # Retry-After 가 이보다 길면 다시 하지 않는다(H20)
NUDGE = "답이 비었다. 필요한 도구를 부르거나, 지금까지 알아낸 것으로 답을 글로 써라."
TOKEN_LIMIT = 400_000          # 단가 없는 두뇌(costBasis unknown)의 한 턴 토큰 상한 기본값(H42)
TYPES = {"string": (str,), "integer": (int,), "number": (int, float), "boolean": (bool,),
         "array": (list,), "object": (dict,), "null": (type(None),)}


def _token_limit(run_value: int | None, profile: dict, basis: str) -> int | None:
    """한 턴 토큰 상한 — 정한 값이 있으면 언제나, 없으면 단가 없는 두뇌에만 기본값."""
    for v in (run_value, profile.get("token_limit"), os.environ.get("ELDA_TOKEN_LIMIT")):
        try:
            if v and int(v) > 0:
                return int(v)
        except ValueError:
            pass
    return TOKEN_LIMIT if basis != "list" else None


def repair_args(args: Any, schema: dict) -> Any:
    """고치기 사다리(H41) 둘째 단 — 문자열로 온 객체·배열을 스키마대로 푼다. 구조를 지어내지 않는다:
    풀어 낸 값의 형이 스키마와 맞을 때만 바꾸고, 아니면 그대로 둔다(검사가 거절한다)."""
    if not isinstance(args, dict):
        return args
    props = schema.get("properties") or {}
    out = dict(args)
    for k, v in args.items():
        want = (props.get(k) or {}).get("type")
        if isinstance(v, str) and want in ("object", "array"):
            try:
                got = json.loads(v)
            except ValueError:
                continue
            if isinstance(got, TYPES[want]):
                out[k] = got
    return out


def diagnose(args: Any, schema: dict) -> dict | None:
    """도구 인자를 스키마 윗단으로 본다(H41). 맞으면 None, 아니면 고칠 수 있게 알리는 칸들."""
    props = schema.get("properties") or {}
    shape = {"required": list(schema.get("required") or []),
             "properties": {k: (v or {}).get("type", "any") for k, v in props.items()}}
    if not isinstance(args, dict):
        return {"category": "not_object", "badField": None, "validShape": shape,
                "message": f"인자는 객체여야 한다 (받은 것: {type(args).__name__})"}
    problems, bad = [], []
    missing = [k for k in schema.get("required") or [] if k not in args]
    if missing:
        problems.append("빠진 인자: " + ", ".join(missing))
        bad += missing
    unknown = [k for k in args if props and k not in props]
    if unknown:
        problems.append("모르는 인자: " + ", ".join(unknown))
        bad += unknown
    for k, v in args.items():
        want = (props.get(k) or {}).get("type")
        names = [want] if isinstance(want, str) else want if isinstance(want, list) else []
        kinds = tuple(t for n in names for t in TYPES.get(n, ()))
        if kinds and (not isinstance(v, kinds) or (isinstance(v, bool) and bool not in kinds)):
            problems.append(f"{k} 의 형이 틀렸다 (기대 {'|'.join(names)}, 받은 것 {type(v).__name__})")
            bad.append(k)
    if not problems:
        return None
    category = "missing_field" if missing else "unknown_field" if unknown else "wrong_type"
    return {"category": category, "badField": bad[0], "validShape": shape,
            "message": ("인자가 도구 스키마에 맞지 않아 실행하지 않았다 — " + " · ".join(problems)
                        + (f". 받는 인자: {', '.join(props)}" if props else "") + ". 고쳐서 다시 불러라.")}


def check_args(args: Any, schema: dict) -> str | None:
    d = diagnose(args, schema)
    return d["message"] if d else None


def arg_error(d: dict) -> str:
    """두뇌에게 돌려줄 인자 오류(H41) — 사람 말 + 고칠 칸. 실행하지 않았으니 sideEffect not_started."""
    return json.dumps({"error": d["message"], "category": d["category"], "badField": d.get("badField"),
                       "validShape": d.get("validShape"), "retryable": True, "sideEffect": "not_started"},
                      ensure_ascii=False)


REFUSAL = {
    "denied": "사람이 거절했다: {r}",
    "timeout": "승인 답을 기다리다 시간이 지나 실행하지 않았다 — 거절은 아니다({r}). 이 턴은 여기서 멈춘다",
    "cancelled": "턴이 중단돼 실행하지 않았다({r})",
    "unavailable": "답할 사람이 없어 실행하지 않았다({r}) — 승인이 필요한 도구는 지금 쓸 수 없다",
}


def refusal_text(outcome: str, reason: str | None) -> str:
    """두뇌에게 주는 문구 — outcome 마다 다르다(H48: 시간 초과는 거절이 아니다)."""
    return REFUSAL.get(outcome, REFUSAL["denied"]).format(r=reason or "이유 없음")


def _env_float(name: str, default: float) -> float:
    try:
        v = float(os.environ.get(name) or default)
    except ValueError:
        return default
    return v if v >= 0 else default


def _env_turns() -> int:
    """ELDA_MAX_TURNS — 한 턴 안 왕복 상한(입구가 업체별로 넘긴다). 틀린 값이면 기본값."""
    try:
        n = int(os.environ.get("ELDA_MAX_TURNS") or MAX_TURNS)
    except ValueError:
        return MAX_TURNS
    return n if n > 0 else MAX_TURNS


class StopReply(Exception):
    """모델이 도구를 실행하면 안 되는 이유로 멈췄다(거절 · 출력 상한)."""

    def __init__(self, message: str, code: str) -> None:
        super().__init__(message)
        self.code = code


class LoopAdapter(Adapter):
    id = "loop"
    title = "우리 루프"
    desc = "모델 연결 + MCP 도구 — 도구 호출을 우리가 실행한다."

    def __init__(self, profile: dict | None = None) -> None:
        self.profile = profile or {}
        # 프로세스 하나 = 대화 하나(--events · 서빙 ③). 잘 끝난 턴의 기록을 다음 턴이 잇는다.
        # 실패·중단된 턴은 버린다(짝 없는 tool_use 가 남으면 다음 요청이 깨진다) — 그 앞까지는 덧붙이기만.
        self.history: list[dict] = []
        self.session_id: str | None = None
        self._mcp: dict | None = None          # {"clients", "route", "tools", "instructions"} — 대화 내내
        self._last_failure: tuple | None = None   # H52 — 앞 턴이 두뇌 오류로 끝났으면 (모델, 코드, 종류, 상태)
        atexit.register(self.close)

    def available(self) -> tuple[bool, str]:          # type: ignore[override]
        try:
            provider = self._provider(None)
        except Exception as e:                        # noqa: BLE001
            return False, str(e)
        return provider.available()

    def _provider(self, spec: str | None):
        """같은 지정이면 대화 내내 같은 연결 — 대본은 이어서 내고, API 클라이언트는 다시 만들지 않는다."""
        from providers import make_provider
        spec = spec or self.profile.get("model")
        if not spec:
            raise ValueError("모델이 정해지지 않았다 (ELDA_MODEL 또는 --model)")
        if getattr(self, "_prov", (None,))[0] != spec:
            self._prov = (spec, make_provider(spec))
        return self._prov[1]

    def run(self, prompt: str, *, cwd: str, approve: Callable[[Event], Decision],
            model: str | None = None, approve_tools: str | None = None, max_turns: int | None = None,
            history: list[dict] | None = None, **_: Any) -> Iterator[Event]:
        from mcp_client import McpError

        resume = _.get("resume")
        if not (resume and resume == self.session_id) and history is None:
            self._new_conversation()
        provider = self._provider(model)
        policy = approve_tools or self.profile.get("approve") or "auto"
        policy = {"ask": "always"}.get(policy, policy)          # ELDA_APPROVE=ask 도 받는다
        bad_cfg = None if policy in ("always", "auto", "never") else f"승인 정책은 always|ask|auto|never 다: {policy!r}"
        ask = policy == "always" or (policy == "auto" and provider.tier != "giant")
        rules = self.profile.get("tools") or {}
        bad = {k: v for k, v in rules.items() if v not in ("allow", "ask", "deny")} if isinstance(rules, dict) else rules
        if bad:
            bad_cfg = f"프로필 tools 는 {{도구: allow|ask|deny}} 여야 한다: {bad}"
        limit = max_turns or self.profile.get("max_turns") or _env_turns()
        strict = provider.id != "anthropic"                 # Claude 가 아닌 두뇌는 인자를 먼저 본다(H41 — GLM 포함)
        basis = getattr(provider, "cost_basis", "unknown")
        budget = _token_limit(_.get("token_limit"), self.profile, basis)
        t0 = time.time()
        usage = {"input": 0, "output": 0, "cacheRead": 0, "cacheWrite": 0}   # 네 칸은 늘 싣는다(하네스 규격 H5)
        turns = calls = retries = empties = malformed = 0
        last_stop: str | None = None
        base = list(history) if history is not None else list(self.history)
        messages: list[dict] = base + [{"role": "user", "content": [{"type": "text", "text": prompt}]}]
        model = f"{provider.id}:{provider.model}"
        extra = {"effort": provider.effort} if getattr(provider, "effort", None) else {}
        gaps = [k for k in getattr(provider, "unreported", ()) if k in usage]
        unreported = {"usageUnreported": gaps} if gaps else {}      # 0 과 '보고 없음' 을 가른다(H5)
        denied = failed = rejected = False
        extra_end: dict = {}

        def end(ok: bool, reason: str, **more: Any) -> dict:
            return {"ok": ok, "endReason": reason, **more, "runCompleted": reason == "completed",
                    "policyRejected": denied or rejected, "toolFailed": failed, **extra_end, "turns": turns, "toolCalls": calls,
                    "diag": {"retries": retries, "emptyRetries": empties, "lastFinishReason": last_stop},   # H53
                    "usage": usage, **unreported, **({"retried": retries} if retries else {}), "costBasis": basis, "durationMs": int((time.time() - t0) * 1000),
                    "model": model, "sessionId": self.session_id, **extra}

        start: dict = {"task": prompt, "model": model, "sessionId": self.session_id, **extra}
        if bad_cfg:                                         # H12 — 모르는 설정은 버리지 않고 거절한다
            yield Event("turn_start", start)
            yield Event("error", {"code": "bad_input", "message": bad_cfg})
            yield Event("turn_end", end(False, "error"))
            return
        try:
            restarted = self._mcp is not None and not self._mcp_alive()
            mcp = self._connect(cwd)
        except (McpError, OSError) as e:
            yield Event("turn_start", start)
            yield Event("error", {"code": "unavailable", "message": f"{type(e).__name__}: {e}"})
            yield Event("turn_end", end(False, "error"))
            return
        if restarted:
            start["mcpRestarted"] = True    # 서버가 죽어 다시 띄웠다 — 앞 턴의 작업 상태는 없다
        yield Event("turn_start", start)
        try:
            route, tools = mcp["route"], mcp["tools"]
            schemas = {t["name"]: t.get("inputSchema") or {} for t in tools} if strict else {}
            meta = {t["name"]: t for t in tools}

            def ask_for(name: str) -> bool | str:
                """도구별 정책(H51) — deny 가 이긴다 · 프로필 규칙 · readOnlyHint 는 기본 allow · 나머지는 프로필 기본."""
                t = meta.get(name) or {}
                keys = {name, route[name][1]} if name in route else {name}
                got = {rules[k] for k in keys if k in rules}
                if not got and f"{mcp['server_of'].get(name)}:*" in rules:
                    got = {rules[f"{mcp['server_of'][name]}:*"]}     # 이름 규칙이 없으면 서버 통째 규칙("서버:*")
                if "deny" in got:
                    return "deny"
                if "ask" in got:
                    return True
                # readOnlyHint 는 *기본* 일 뿐 — 실행 단위로 승인을 정해 주면(--approve ask → approve_tools) 그것이 이긴다
                if "allow" in got or (not approve_tools and (t.get("annotations") or {}).get("readOnlyHint") is True):
                    return False
                return ask

            offered = [t for t in tools if ask_for(t["name"]) != "deny"]    # 막힌 도구는 두뇌에게 보이지 않는다
            system = "\n\n".join([self.profile.get("system", ""), *mcp["instructions"]]).strip()

            reason = "completed"
            retried = False
            while True:
                if turns >= limit:
                    # 기록은 남긴다 — 끝이 tool_result(user)라 다음 요청이 그대로 유효하고, MCP 의 작업 상태와도 맞는다
                    yield Event("error", {"code": "max_turns", "message": f"턴 상한 {limit} 에 닿았다 — 멈춘다"})
                    reason = "max_turns"
                    break
                spent = sum(v for v in usage.values() if isinstance(v, (int, float)))
                if budget and spent >= budget:
                    yield Event("error", {"code": "token_limit", "message": f"토큰 상한 {budget} 에 닿았다({spent}) — 멈춘다"})
                    reason = "token_limit"
                    break
                turns += 1
                ask_msgs = messages if empties < 2 else messages + [
                    {"role": "user", "content": [{"type": "text", "text": NUDGE}]}]       # H49 — 둘째 다시는 짧은 재촉
                try:
                    reply = provider.complete(system, ask_msgs, offered)
                except ApiError as e:
                    # H20 — 일시 오류(429·5xx·연결 끊김)만, 도구가 돌기 전에만, 턴에 한 번. Retry-After 를 지킨다.
                    wait = e.retry_after if e.retry_after is not None else _env_float("ELDA_RETRY_DELAY", 2.0)
                    if not (e.transient and calls == 0 and retries == 0 and wait <= RETRY_MAX_WAIT):
                        raise
                    retries += 1
                    turns -= 1
                    yield Event("retry", {"attempt": retries, "status": e.status, "apiError": e.kind,
                                          "delayMs": int(wait * 1000)})
                    time.sleep(wait)
                    continue
                last_stop = reply.stop
                for k, v in reply.usage.items():
                    if isinstance(v, (int, float)):
                        usage[k] = usage.get(k, 0) + v
                if reply.served_by:
                    extra["servedBy"] = reply.served_by
                if (reply.stop == "length" and strict and not retried
                        and not any(b["type"] == "text" and b.get("text", "").strip() for b in reply.content)):
                    retried = True                          # 답 없이 잘렸다 — 상한 안에서 한 번만 다시(H41)
                    continue
                if reply.stop in ("refusal", "length"):
                    # 도구를 실행하지 않는다 — 잘린 tool_use 를 돌리거나 거절을 답처럼 보이면 안 된다
                    raise StopReply({"refusal": f"모델이 거절했다 — {reply.detail or '분류 없음'}",
                                     "length": "답이 출력 상한(max_tokens)에서 잘렸다"}[reply.stop],
                                    "output_limit" if reply.stop == "length" else "refusal")
                if not any((b["type"] == "text" and b.get("text", "").strip()) or b["type"] == "tool_use"
                           for b in reply.content):
                    if empties < 2:                         # H49 — 같은 요청으로 한 번, 짧은 재촉으로 한 번
                        empties += 1
                        continue
                    yield Event("error", {"code": "stalled", "message": "모델이 글도 도구 호출도 없는 빈 답을 냈다 — 멈춘다"})
                    reason = "stalled"
                    break
                messages.append({"role": "assistant", "content": reply.content})
                for block in reply.content:
                    if block["type"] == "text" and block["text"].strip():
                        yield Event("text", {"text": block["text"]})
                uses = [b for b in reply.content if b["type"] == "tool_use"]
                if not uses:
                    break
                results = []
                for use in uses:
                    calls += 1
                    blocked = False
                    if use.get("input") is None:
                        use["input"] = {}                   # HCX 는 인자 없는 호출에 arguments:null 을 낸다(H41)
                    ev = {"tool": use["name"], "input": use["input"], "callId": use["id"]}
                    yield Event("tool_call", ev)
                    effect = "not_started"
                    if denied:
                        # 승인은 하나씩(H38 ⑦) — 앞 호출이 거절되면 남은 호출은 묻지도 실행하지도 않는다
                        ok, output = False, "앞 도구 호출이 거절돼 실행하지 않았다"
                    else:
                        ok, output, effect = self._run_tool(use, route, ask_for(use["name"]), schemas)
                        if output.startswith('{"error"') and effect == "not_started" and '"retryable"' in output:
                            malformed += 1                  # 인자 잘못 — 이어지면 멈춘다(H41)
                        elif effect != "not_started" or output == "__ask__":
                            malformed = 0
                        if output == "__deny__":
                            blocked = True
                            rejected = True
                            ok, output = False, f"정책이 막은 도구다: {use['name']} — 다른 방법을 써라"
                        if output == "__ask__":
                            yield Event("approval", ev)
                            decision = approve(Event("approval", ev))
                            if decision.allow:
                                ok, output, effect = self._call(use, route)
                            else:
                                denied = True
                                outcome = decision.outcome or "denied"
                                extra_end["approvalOutcome"] = outcome
                                ok, output = False, refusal_text(outcome, decision.reason)
                        if not ok and not denied and not blocked:
                            failed = True
                    if len(output) > MAX_RESULT_CHARS:
                        output = output[:MAX_RESULT_CHARS] + f"\n…(결과 {len(output)}자 중 {MAX_RESULT_CHARS}자만 보냈다)"
                    yield Event("tool_result", {"tool": use["name"], "callId": use["id"], "ok": ok, "output": output,
                                                "sideEffect": effect})
                    results.append({"type": "tool_result", "tool_use_id": use["id"], "content": output, "is_error": not ok})
                messages.append({"role": "user", "content": results})
                if denied:
                    reason = "denied"                       # 거절 뒤 ok:true 가 나가지 않게(H40)
                    break
                if malformed >= MALFORMED_LIMIT:
                    yield Event("error", {"code": "malformed_tool_use",
                                          "message": f"도구 인자 잘못이 {malformed}번 이어졌다 — 멈춘다"})
                    reason = "malformed_tool_use"
                    break
            if history is None:
                self.history = messages
            self._last_failure = None
            done = end(reason == "completed", reason, messages=len(messages))
            if os.environ.get("ELDA_HISTORY") == "1":
                done["history"] = messages
            yield Event("turn_end", done)
        except StopReply as e:
            yield Event("error", {"code": e.code, "message": str(e)})
            yield Event("turn_end", end(False, "output_limit" if e.code == "output_limit" else "error"))
        except (McpError, OSError, RuntimeError, ValueError) as e:
            err: dict = {"code": "adapter", "message": f"{type(e).__name__}: {e}"}     # code 는 늘 싣는다(H4)
            more: dict = {}
            if isinstance(e, ApiError):
                err["code"] = "api_error"
                err["apiError"] = e.kind                    # H50 분류
                more["apiError"] = e.kind
                if e.status:
                    more["apiErrorStatus"] = e.status      # 숫자만(하네스 H33)
            yield Event("error", err)
            sig = (model, err["code"], more.get("apiError"), more.get("apiErrorStatus"))
            if sig == self._last_failure:
                # H52 — 같은 두뇌·같은 오류가 두 턴 이어졌다(목록엔 있지만 서빙이 안 되는 모델 등)
                yield Event("notice", {"code": "brain_unhealthy", "model": model,
                                       "text": f"{model} 이 두 턴 이어 같은 오류({more.get('apiError') or err['code']})로 실패했다"})
            self._last_failure = sig
            yield Event("turn_end", end(False, "error", **more))

    # ── 대화 수명 ──────────────────────────────────────────────────────────────
    def _new_conversation(self) -> None:
        self.close()
        self.history = []
        self.session_id = uuid.uuid4().hex
        self._prov = (None, None)

    def _mcp_alive(self) -> bool:
        return bool(self._mcp) and all(c._proc is not None and c._proc.poll() is None and not c._dead
                                       for c in self._mcp["clients"])

    def _connect(self, cwd: str) -> dict:
        """MCP 서버를 띄우고 도구를 모은다(대화에 한 번). 이름이 겹치면 '서버.도구' 로 구분한다."""
        from mcp_client import McpClient
        if self._mcp is not None and self._mcp_alive():
            return self._mcp
        self.close()
        mcp: dict = {"clients": [], "route": {}, "tools": [], "instructions": [], "server_of": {}}
        try:
            for server in self.profile.get("servers", []):
                client = McpClient(server["command"], cwd=server.get("cwd") or cwd, env=server.get("env"))
                mcp["clients"].append(client)
                client.start()
                if client.instructions and server.get("instructions", True):   # False = 지시문을 싣지 않는다(H44 가볍게)
                    mcp["instructions"].append(client.instructions)
                for tool in client.list_tools():
                    name = tool["name"] if tool["name"] not in mcp["route"] else f"{server['name']}.{tool['name']}"
                    mcp["route"][name] = (client, tool["name"])
                    mcp["server_of"][name] = server["name"]
                    mcp["tools"].append({**tool, "name": name})
        except Exception:
            for c in mcp["clients"]:
                c.close()
            raise
        self._mcp = mcp
        return mcp

    def close(self) -> None:
        """대화 끝 — MCP 서버를 닫는다(입력을 닫으면 서버가 스스로 정리한다)."""
        mcp, self._mcp = self._mcp, None
        for c in (mcp or {}).get("clients", []):
            try:
                c.close()
            except Exception as e:                    # noqa: BLE001
                print(f"elda: MCP 닫기 실패: {e}", file=sys.stderr)

    def _run_tool(self, use: dict, route: dict, ask: bool | str, schemas: dict) -> tuple[bool, str, str]:
        """(ok, 결과, sideEffect) — 실행 전에 멈추면 not_started(H40)."""
        if ask == "deny":
            return False, "__deny__", "not_started"
        if use.get("invalid"):
            return False, arg_error({"message": use["invalid"], "category": "invalid_json", "badField": None,
                                     "validShape": None}), "not_started"
        if use["name"] not in route:
            return False, f"없는 도구: {use['name']} (있는 것: {', '.join(route)})", "not_started"
        if schemas:
            schema = schemas.get(use["name"]) or {}
            use["input"] = repair_args(use["input"], schema)
            bad = diagnose(use["input"], schema)
            if bad:
                return False, arg_error(bad), "not_started"
        if ask:
            return False, "__ask__", "not_started"
        return self._call(use, route)

    @staticmethod
    def _call(use: dict, route: dict) -> tuple[bool, str, str]:
        from mcp_client import McpError
        client, name = route[use["name"]]
        try:
            result = client.call_tool(name, use["input"])
        except McpError as e:
            return False, f"도구 실행 실패: {e}", "unknown"     # 보냈는데 답을 못 받았다 — 돌았는지 모른다
        return result.ok, result.text or json.dumps(result.raw, ensure_ascii=False)[:2000], "completed"
