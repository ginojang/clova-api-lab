"""MCP 클라이언트 — 표준 입출력(stdio) MCP 서버를 띄우고 도구를 부른다. **표준 라이브러리만.**

elda 가 도구 호출 루프를 **직접** 돌리기 위한 손이다(docs/CLI_프레임워크_설계.md §6). 거인 엔진을 감싸는
어댑터는 도구 실행을 그쪽이 했지만, 우리 루프는 모델이 고른 도구를 여기서 실행한다.

    with McpClient(["node", "main.ts", "mcp", ...]) as mcp:
        tools = mcp.list_tools()                     # [{name, description, inputSchema}]
        result = mcp.call_tool("batch", {"steps": [...]})   # ToolResult(ok, text, raw)

규약: 줄 단위 JSON-RPC 2.0 (MCP stdio). 서버 로그는 stderr 로 오므로 따로 모은다.
"""
from __future__ import annotations

import json
import os
import subprocess
import threading
from dataclasses import dataclass
from typing import Any

PROTOCOL_VERSION = "2025-06-18"
DEFAULT_TIMEOUT_S = 120.0


class McpError(RuntimeError):
    """서버가 JSON-RPC 오류로 답했거나, 죽었거나, 시간 안에 답하지 않았다."""


@dataclass
class ToolResult:
    ok: bool            # isError 가 아니면 True
    text: str           # content 의 text 조각을 이어 붙인 것
    raw: dict           # 서버가 준 result 그대로


class McpClient:
    def __init__(self, command: list[str], *, cwd: str | None = None, env: dict | None = None,
                 timeout_s: float = DEFAULT_TIMEOUT_S, client_name: str = "elda") -> None:
        self.command = command
        self.cwd = cwd
        self.env = {**os.environ, **(env or {})}
        self.timeout_s = timeout_s
        self.client_name = client_name
        self.server_info: dict = {}
        self.instructions: str = ""
        self._proc: subprocess.Popen | None = None
        self._next_id = 1
        self._lock = threading.Lock()
        self._pending: dict[int, dict] = {}
        self._ready: dict[int, threading.Event] = {}
        self._stderr: list[str] = []
        self._dead: str | None = None

    # ── 수명 ─────────────────────────────────────────────────────────────────
    def __enter__(self) -> "McpClient":
        self.start()
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()

    def start(self) -> None:
        self._proc = subprocess.Popen(self.command, cwd=self.cwd, env=self.env, stdin=subprocess.PIPE,
                                      stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, bufsize=1)
        threading.Thread(target=self._read_stdout, daemon=True).start()
        threading.Thread(target=self._read_stderr, daemon=True).start()
        init = self.request("initialize", {
            "protocolVersion": PROTOCOL_VERSION,
            "capabilities": {},
            "clientInfo": {"name": self.client_name, "version": "0.1.0"},
        })
        self.server_info = init.get("serverInfo", {})
        self.instructions = init.get("instructions", "") or ""
        self._send({"method": "notifications/initialized"})

    def close(self, timeout_s: float = 5.0) -> None:
        """입력을 닫아 서버가 스스로 정리하게 한다. 시간 안에 안 끝나면 신호로 끝낸다."""
        p = self._proc
        if not p:
            return
        try:
            if p.poll() is None:
                p.stdin.close()
                p.wait(timeout=timeout_s)
        except subprocess.TimeoutExpired:
            p.terminate()
            try:
                p.wait(timeout=timeout_s)
            except subprocess.TimeoutExpired:
                p.kill()
                p.wait()
        finally:
            for pipe in (p.stdin, p.stdout, p.stderr):
                try:
                    if pipe and not pipe.closed:
                        pipe.close()
                except OSError:
                    pass

    @property
    def stderr_tail(self) -> str:
        return "".join(self._stderr[-20:])

    # ── 도구 ─────────────────────────────────────────────────────────────────
    def list_tools(self) -> list[dict]:
        return self.request("tools/list").get("tools", [])

    def call_tool(self, name: str, arguments: dict | None = None) -> ToolResult:
        result = self.request("tools/call", {"name": name, "arguments": arguments or {}})
        text = "".join(c.get("text", "") for c in result.get("content", []) if c.get("type") == "text")
        return ToolResult(ok=not result.get("isError", False), text=text, raw=result)

    # ── JSON-RPC ─────────────────────────────────────────────────────────────
    def request(self, method: str, params: dict | None = None) -> dict:
        if self._dead:
            raise McpError(self._dead)
        with self._lock:
            rid = self._next_id
            self._next_id += 1
            ready = self._ready[rid] = threading.Event()
        self._send({"id": rid, "method": method, "params": params or {}})
        if not ready.wait(self.timeout_s):
            self._ready.pop(rid, None)
            raise McpError(f"{method}: {self.timeout_s:.0f}초 안에 답이 없다")
        reply = self._pending.pop(rid, None)
        self._ready.pop(rid, None)
        if reply is None:
            raise McpError(self._dead or f"{method}: 서버가 답하지 않고 끝났다")
        if "error" in reply:
            raise McpError(f"{method}: {reply['error'].get('message', reply['error'])}")
        return reply.get("result", {})

    def _send(self, message: dict) -> None:
        p = self._proc
        if not p or p.poll() is not None:
            raise McpError(self._dead or "서버가 떠 있지 않다")
        try:
            p.stdin.write(json.dumps({"jsonrpc": "2.0", **message}, ensure_ascii=False) + "\n")
            p.stdin.flush()
        except (BrokenPipeError, ValueError) as e:
            raise McpError(f"서버에 쓸 수 없다: {e}") from e

    def _read_stdout(self) -> None:
        assert self._proc and self._proc.stdout
        for line in self._proc.stdout:
            line = line.strip()
            if not line:
                continue
            try:
                msg = json.loads(line)
            except json.JSONDecodeError:
                # stdout 에는 프로토콜만 와야 한다 — 아닌 줄은 버리지 않고 stderr 몫으로 남긴다(조용히 버리지 않는다)
                self._stderr.append(f"[stdout 비프로토콜] {line}\n")
                continue
            rid = msg.get("id")
            if isinstance(rid, int) and rid in self._ready:
                self._pending[rid] = msg
                self._ready[rid].set()
        code = self._proc.wait()
        self._dead = f"서버가 끝났다 (종료 코드 {code}). {self.stderr_tail.strip()[-300:]}"
        for ev in list(self._ready.values()):
            ev.set()

    def _read_stderr(self) -> None:
        assert self._proc and self._proc.stderr
        for line in self._proc.stderr:
            self._stderr.append(line)
            if len(self._stderr) > 200:
                del self._stderr[:100]
