"""NAVER CLOVA Studio (HyperCLOVA X) 연결 — 운영 에이전트의 두뇌(② 구동, 풀스택 11-11 C1).

계약 = 클로버 K1 `OPS-PROVIDER-HANDOFF-2026-11-11.md`(clova-api-lab runtime/clova provider.ts 기준). 표준 라이브러리만 쓴다.

    clova:HCX-005        도구 호출 · effort 없음(ELDA_EFFORT 를 주면 거절 — 하네스 H12)
    clova:HCX-007        추론 모델 · ELDA_EFFORT = none(기본)·low·medium·high — 도구와 같이 쓰면 none 만

  · 엔드포인트 = NAVER 고유 v3: POST {CLOVA_BASE_URL}/v3/chat-completions/<모델> (OpenAI 호환 아님)
  · 열쇠 = CLOVA_API_KEY_FILE(없으면 ~/.config/elda/clova.key) — **키 값만 든 600 파일**(dotenv 아님).
    Authorization: Bearer <키>. 어디에도 찍지 않는다.
  · 출력 상한 = ELDA_CLOVA_MAX_TOKENS(기본 2048, 1..2048 · 도구가 있으면 1024 이상) — 랩이 정한 상한을 따른다.
    005 는 maxTokens, 007 은 maxCompletionTokens. temperature 0.
  · usage: promptTokens·completionTokens → input·output, 캐시 칸은 0. 단가표가 없다 → costBasis unknown(H42).
  · 도구 호출: message.toolCalls[].function.arguments(객체 · 문자열이면 JSON) — null 은 {}. 객체가 아니면 그 호출만
    invalid 로 표시해 루프가 고칠 수 있는 오류로 돌려준다(H41). 한 응답에 여러 호출이 올 수 있다.
  · 007 의 thinkingContent 는 버린다 — 다음 요청에 되돌려 보내지 않는다(NAVER 안내).
  · 재시도 0회 — 다시 하기는 하네스 몫(H20). 오류는 HTTP 상태 + NAVER status.code·message(160자)만 싣는다.
  · 빈 tool description 은 NAVER 가 400 으로 거절한다 — 도구 이름으로 채운다.
"""
from __future__ import annotations

import json
import os
import re
import stat
import urllib.error
import urllib.parse
import urllib.request

from . import ApiError, retry_after, Provider, Reply

MODELS = ("HCX-005", "HCX-007")
BASE_URL = "https://clovastudio.stream.ntruss.com"
KEY_FILE = "~/.config/elda/clova.key"
MAX_TOKENS = 2048
EFFORTS = ("none", "low", "medium", "high")
STOP = {"stop": "end", "length": "length", "tool_calls": "tool_use"}
TIMEOUT_S = 60


class Clova(Provider):
    id = "clova"
    tier = "api"                 # 거인이 아니다 — auto 면 도구마다 묻고, 도구 인자를 먼저 본다(H41)
    cost_basis = "unknown"
    unreported = ("cacheRead", "cacheWrite")            # v3 는 캐시 칸을 보고하지 않는다

    def __init__(self, model: str) -> None:
        self.model = model or "HCX-005"
        if self.model not in MODELS:
            raise ValueError(f"clova:{self.model} — 검토된 모델만 쓴다: {' · '.join(MODELS)}")
        effort = os.environ.get("ELDA_EFFORT")
        if self.model == "HCX-007":
            self.effort = effort or "none"
            if self.effort not in EFFORTS:
                raise ValueError(f"ELDA_EFFORT={effort} — HCX-007 은 {' · '.join(EFFORTS)} 중 하나")
        elif effort:
            raise ValueError(f"ELDA_EFFORT={effort} — {self.model} 은 effort 를 받지 않는다(하네스 H12: 버리지 않고 거절)")
        else:
            self.effort = None
        try:
            self.max_tokens = int(os.environ.get("ELDA_CLOVA_MAX_TOKENS") or MAX_TOKENS)
        except ValueError:
            raise ValueError("ELDA_CLOVA_MAX_TOKENS 는 정수다") from None
        if not 1 <= self.max_tokens <= MAX_TOKENS:
            raise ValueError(f"ELDA_CLOVA_MAX_TOKENS 는 1..{MAX_TOKENS}")
        self.base_url = (os.environ.get("CLOVA_BASE_URL") or BASE_URL).rstrip("/")
        u = urllib.parse.urlsplit(self.base_url)
        if not (u.scheme == "https" or (u.scheme == "http" and u.hostname in ("127.0.0.1", "localhost", "::1"))):
            raise ValueError("CLOVA_BASE_URL 은 https 여야 한다(시험용 loopback http 만 예외)")

    # ── 열쇠 ────────────────────────────────────────────────────────────────
    @staticmethod
    def key_path() -> str:
        return os.path.expanduser(os.environ.get("CLOVA_API_KEY_FILE") or KEY_FILE)

    def _key(self) -> tuple[str | None, str]:
        path = self.key_path()
        try:
            st = os.stat(path)
        except OSError:
            return None, f"CLOVA 열쇠 파일이 없다({'CLOVA_API_KEY_FILE' if os.environ.get('CLOVA_API_KEY_FILE') else KEY_FILE})"
        if not stat.S_ISREG(st.st_mode) or stat.S_IMODE(st.st_mode) != 0o600:
            return None, "CLOVA 열쇠 파일은 권한 600 인 일반 파일이어야 한다"
        try:
            with open(path, encoding="utf-8") as f:
                key = f.read().strip()
        except OSError:
            return None, "CLOVA 열쇠 파일을 읽지 못했다"
        if not key:
            return None, "CLOVA 열쇠 파일이 비었다"
        if "\n" in key or re.match(r"(export\s+)?[A-Z_][A-Z0-9_]*=", key):
            return None, "CLOVA 열쇠 파일에는 키 값 한 줄만 둔다(KEY=value 꼴 아님)"
        return key, ""

    def available(self) -> tuple[bool, str]:
        key, why = self._key()
        if not key:
            return False, why
        return True, f"clova · {self.model}" + (f" · effort {self.effort}" if self.effort else "")

    # ── 요청 모양 ────────────────────────────────────────────────────────────
    @staticmethod
    def to_clova(system: str, messages: list[dict]) -> list[dict]:
        """루프의 블록(Anthropic 꼴) → CLOVA v3 메시지. system 은 요청당 하나."""
        out: list[dict] = [{"role": "system", "content": system}] if system else []
        for m in messages:
            if m["role"] == "assistant":
                text = "\n".join(b["text"] for b in m["content"] if b["type"] == "text")
                calls = [{"id": b["id"], "type": "function",
                          "function": {"name": b["name"], "arguments": b.get("input") or {}}}
                         for b in m["content"] if b["type"] == "tool_use"]
                msg: dict = {"role": "assistant", "content": text}
                if calls:
                    msg["toolCalls"] = calls
                out.append(msg)
                continue
            for b in m["content"]:
                if b["type"] == "tool_result":
                    content = b["content"] if isinstance(b["content"], str) else json.dumps(b["content"], ensure_ascii=False)
                    out.append({"role": "tool", "toolCallId": b["tool_use_id"], "content": content})
            texts = [b["text"] for b in m["content"] if b["type"] == "text"]
            if texts:
                out.append({"role": "user", "content": "\n".join(texts)})
        return out

    def body(self, system: str, messages: list[dict], tools: list[dict]) -> dict:
        if tools and self.max_tokens < 1024:
            raise ValueError("CLOVA 도구 호출은 출력 상한 1024 이상이 필요하다(ELDA_CLOVA_MAX_TOKENS)")
        body: dict = {"messages": self.to_clova(system, messages), "temperature": 0}
        if self.model == "HCX-007":
            if tools and self.effort != "none":
                raise ValueError(f"HCX-007 은 추론(effort {self.effort})과 도구 호출을 같이 쓸 수 없다 — ELDA_EFFORT=none")
            body["maxCompletionTokens"] = self.max_tokens
            body["thinking"] = {"effort": self.effort}
        else:
            body["maxTokens"] = self.max_tokens
        if tools:
            # NAVER 는 빈 description 을 400(40001)으로 거절한다(11-11 실호출) — 없으면 도구 이름을 쓴다
            body["tools"] = [{"type": "function", "function": {"name": t["name"],
                                                               "description": (t.get("description") or "").strip() or t["name"],
                                                               "parameters": t.get("inputSchema") or {"type": "object"}}}
                             for t in tools]
        return body

    # ── 응답 모양 ────────────────────────────────────────────────────────────
    @staticmethod
    def from_clova(message: dict) -> list[dict]:
        blocks: list[dict] = []
        if message.get("content"):
            blocks.append({"type": "text", "text": message["content"]})
        seen: set[str] = set()
        for call in message.get("toolCalls") or []:
            fn = call.get("function") if isinstance(call, dict) else None
            cid = call.get("id") if isinstance(call, dict) else None
            if not (isinstance(cid, str) and cid and cid not in seen and isinstance(fn, dict)
                    and isinstance(fn.get("name"), str)):
                raise ApiError("clova: 도구 호출 모양이 틀렸다(id 없음·중복·이름 없음)", kind="unknown")
            seen.add(cid)
            raw, bad = fn.get("arguments"), None
            if raw is None:
                raw = {}                                    # HCX-005 실측 arguments:null(H41)
            if isinstance(raw, str):
                try:
                    raw = json.loads(raw) if raw.strip() else {}
                except json.JSONDecodeError as e:
                    raw, bad = {}, f"인자가 JSON 이 아니다: {e}"
            if not isinstance(raw, dict):
                raw, bad = {}, f"인자가 객체가 아니다: {type(raw).__name__}"
            block = {"type": "tool_use", "id": cid, "name": fn["name"], "input": raw}
            if bad:
                block["invalid"] = bad
            blocks.append(block)
        return blocks

    def complete(self, system: str, messages: list[dict], tools: list[dict]) -> Reply:
        key, why = self._key()
        if not key:
            raise RuntimeError(why)
        req = urllib.request.Request(f"{self.base_url}/v3/chat-completions/{self.model}",
                                     data=json.dumps(self.body(system, messages, tools), ensure_ascii=False).encode(),
                                     headers={"Content-Type": "application/json", "Authorization": f"Bearer {key}"})
        try:
            with urllib.request.urlopen(req, timeout=TIMEOUT_S) as r:
                data = json.load(r)
        except urllib.error.HTTPError as e:
            code = why = ""
            try:
                st = json.load(e).get("status") or {}
                code, why = str(st.get("code") or "")[:20], str(st.get("message") or "")[:160]
            except (ValueError, AttributeError, OSError):
                pass
            # NAVER status 의 code·message 만 싣는다(어느 칸이 틀렸는지) — 요청 본문·열쇠는 옮기지 않는다
            raise ApiError(f"clova {e.code}" + (f" (status {code}: {why})" if code else ""), e.code,
                           retry_after=retry_after(e.headers)) from None
        except TimeoutError:
            raise ApiError(f"clova: {TIMEOUT_S}초 안에 답이 없다", 504) from None
        except (urllib.error.URLError, OSError) as e:
            raise ApiError(f"clova 연결 실패: {type(e).__name__}", connection=True) from None
        except ValueError:
            raise ApiError("clova: 답이 JSON 이 아니다", kind="unknown") from None
        if not isinstance(data, dict):
            raise ApiError("clova: 답 모양이 틀렸다", kind="unknown")
        st = data.get("status") or {}
        status = str(st.get("code") or "")
        if status and status != "20000":
            # HTTP 200 인데 본문이 실패(H20) — NAVER 코드 앞 세 자리가 HTTP 상태와 같은 뜻이다(40001→400, 42901→429).
            # 그 코드가 일시일 때만 일시로 본다. 예전처럼 502 로 바꾸지 않는다.
            http = int(status[:3]) if status[:3].isdigit() else None
            raise ApiError(f"clova: 요청이 거절됐다(status {status[:20]}: {str(st.get('message') or '')[:160]})", http)
        res = data.get("result") or {}
        msg = res.get("message") or {}
        if msg.get("role") != "assistant" or not isinstance(msg.get("content"), str):
            raise ApiError("clova: 답 모양이 틀렸다(message)", kind="unknown")
        finish = res.get("finishReason")
        if finish not in STOP:
            raise ApiError(f"clova: 모르는 finishReason {str(finish)[:20]}", kind="unknown")
        u = res.get("usage") or {}
        pt, ct = u.get("promptTokens"), u.get("completionTokens")
        if not all(isinstance(v, (int, float)) and not isinstance(v, bool) and v >= 0 for v in (pt, ct)):
            raise ApiError("clova: 답에 토큰 사용량이 없다", kind="unknown")
        content = self.from_clova(msg)                      # thinkingContent 는 여기서 빠진다
        if finish == "tool_calls" and not any(b["type"] == "tool_use" for b in content):
            raise ApiError("clova: tool_calls 인데 호출이 없다", kind="unknown")
        return Reply(content=content, stop=STOP[finish],
                     usage={"input": int(pt), "output": int(ct), "cacheRead": 0, "cacheWrite": 0})
