"""모델 연결 — 우리 도구 호출 루프(adapters/loop.py)가 부르는 LLM.

루프는 메시지를 **한 가지 모양**으로만 다룬다(아래 블록). 모델마다 다른 형식은 연결이 바꾼다.
그래서 디코더를 바꾸는 일(Claude → gpt-4o-mini · GLM · Ollama)은 **연결 하나 추가**로 끝난다.

메시지 = {"role": "user" | "assistant", "content": [블록, …]}
블록   = {"type": "text", "text"}
       | {"type": "tool_use", "id", "name", "input"}                      ← assistant
       | {"type": "tool_result", "tool_use_id", "content", "is_error"}   ← user
도구   = {"name", "description", "inputSchema"}                           ← MCP 의 tools/list 그대로

모델 지정 문자열(ELDA_MODEL · --model):
    ollama:qwen3:14b              Ollama (OpenAI 형식, 기본 주소 http://127.0.0.1:11434/v1)
    openai:gpt-4o-mini            OpenAI (OPENAI_API_KEY)
    openai-compat:<모델>@<주소>    OpenAI 형식이면 무엇이든 (GLM 등, ELDA_API_KEY)
    anthropic:claude-opus-5-5     Claude API (공식 SDK, ELDA_VENV · ANTHROPIC_API_KEY · ELDA_EFFORT)
    scripted:<대본.json>          시험용 대본

블록에는 위 셋 말고도 연결이 그대로 되돌려 받아야 하는 것(anthropic 의 thinking · fallback)이 섞일 수 있다.
루프는 모르는 블록을 보여 주지 않고 **그대로 둔다**(대화는 덧붙이기만).
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field


@dataclass
class Reply:
    content: list[dict]                 # 위 블록 모양 (text · tool_use)
    stop: str = ""                      # end · tool_use · length · refusal · …
    usage: dict = field(default_factory=dict)   # {"input", "output"[, "cacheRead", "cacheWrite"]}
    detail: str = ""                    # stop 의 사정(거절 분류 등)
    served_by: str = ""                 # 서버 폴백으로 다른 모델이 답했으면 그 모델


RETRY_STATUS = (429, 500, 502, 503, 529)              # 하네스 H20 — 다시 해 볼 만한 일시 오류(+ 연결 끊김)


def classify(status: int | None) -> str:
    """두뇌 오류 종류(하네스 H50) — H20 의 다시 하기 판단이 이것으로 간다."""
    if status in (401, 403):
        return "authentication_failed"
    if status == 402:
        return "billing_error"
    if status == 429:
        return "rate_limit"
    if status == 404:
        return "model_not_found"
    if status in (400, 409, 413, 422):
        return "invalid_request"
    if isinstance(status, int) and (status >= 500 or status == 529):
        return "server_error"
    return "unknown"


def retry_after(headers) -> float | None:
    """Retry-After(초) — 날짜 꼴·틀린 값은 무시한다."""
    try:
        v = float((headers or {}).get("Retry-After") or (headers or {}).get("retry-after") or "")
    except (TypeError, ValueError, AttributeError):
        return None
    return v if v >= 0 else None


class ApiError(RuntimeError):
    """두뇌 API 가 오류로 답했다 — status 는 숫자만(열쇠·본문은 메시지에 넣지 않는다, 공급자 글은 160자 안).

    kind = H50 분류 · transient = H20 일시 오류(다시 해 볼 만하다) · retry_after = 공급자가 준 기다림(초).
    """

    def __init__(self, message: str, status: int | None = None, *, kind: str | None = None,
                 retry_after: float | None = None, connection: bool = False) -> None:
        super().__init__(message)
        self.status = status
        self.kind = kind or ("server_error" if connection else classify(status))
        self.retry_after = retry_after
        self.transient = connection or status in RETRY_STATUS


class Provider:
    id = "base"
    # 승인 기본값을 가른다(에이전트 성능별 승인 — 거인은 승인 없이, 로컬·시험 모델은 도구마다).
    tier = "giant"
    model = ""
    # 비용 출처(H42) — list(입구 단가표 → 비용 상한) · managed(관문이 셈) · unknown. list 가 아니면 루프가 토큰 상한으로 막는다
    cost_basis = "unknown"
    # 두뇌가 보고하지 않는 usage 칸(H5) — turn_end.usageUnreported 로 밝힌다(0 = 실제 0 과 가르기)
    unreported: tuple = ()

    def available(self) -> tuple[bool, str]:
        return True, ""

    def complete(self, system: str, messages: list[dict], tools: list[dict]) -> Reply:
        raise NotImplementedError


def make_provider(spec: str) -> Provider:
    from .openai_compat import OpenAICompat
    kind, _, rest = spec.partition(":")
    if kind == "ollama":
        model, _, url = rest.partition("@")
        return OpenAICompat(model=model, base_url=url or "http://127.0.0.1:11434/v1", key_env=None, tier="local", label="ollama")
    if kind == "openai":
        return OpenAICompat(model=rest, base_url="https://api.openai.com/v1", key_env="OPENAI_API_KEY", tier="giant", label="openai")
    if kind == "openai-compat":
        model, _, url = rest.partition("@")
        if not url:
            raise ValueError("openai-compat:<모델>@<주소> 형식이다")
        return OpenAICompat(model=model, base_url=url, key_env="ELDA_API_KEY", key_file_env="ELDA_API_KEY_FILE",
                            tier="giant", label="openai-compat")
    if kind == "eldacore":
        # EldaCore 두뇌 관문(brain-gateway G1·D1) — OpenAI 형식. 주소는 ELDA_GATEWAY_URL 또는 @주소,
        # 관문 토큰은 파일로만(ELDA_GATEWAY_KEY_FILE, 600 — H10). 비용은 관문이 원장으로 센다(H42 managed).
        # turn_end.model = eldacore:<이름> — 주소는 싣지 않는다(H5)
        model, _, url = rest.partition("@")
        url = url or os.environ.get("ELDA_GATEWAY_URL", "")
        if not model or not url:
            raise ValueError("eldacore:<이름> 은 ELDA_GATEWAY_URL(또는 eldacore:<이름>@<주소>)이 있어야 한다")
        return OpenAICompat(model=model, base_url=url, key_env=None, key_file_env="ELDA_GATEWAY_KEY_FILE",
                            tier="giant", label="eldacore", cost_basis="managed")
    if kind == "clova":
        from .clova import Clova
        return Clova(rest)
    if kind == "anthropic":
        from .anthropic_api import AnthropicAPI
        return AnthropicAPI(rest)
    if kind == "scripted":
        from .scripted import Scripted
        return Scripted(rest)
    raise ValueError(f"모르는 모델 지정: {spec} (ollama: · openai: · openai-compat: · eldacore: · clova: · anthropic: · scripted:)")
