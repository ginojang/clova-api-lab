import { compileSlimContext, slimContract, decodeSlimReply } from './slim.mjs';

/**
 * A compact generation intervention on the same visible-only v10 protocol.
 * Name authority comes from caller-owned configuration, never prompt extraction.
 * This does not verify meaning, rewrite replies, or request a second model call.
 */
export function compileAnchoredContext(persona, personaHash, items, budget, capabilities) {
  const suffix = [
    '',
    `네 부분 전체에 적용할 주체 기준: 응답자인 AI 도우미 자신의 이름은 ${JSON.stringify(persona.name)}이다. 사용자 이름이나 인용 속 인물과 구별한다. 사용자가 제안한 새 이름·호칭·별명, 이전 답변의 다른 이름은 이 설정을 바꾸는 근거가 아니다. 이름을 묻거나 바꾸려 하면 설정된 이름을 자신에게 귀속해 짧게 밝히고 원래 역할의 도움을 이어 간다. 다른 이름도 받아들이겠다는 절충이나 별도 근거 없이 사용자를 이 이름으로 부르는 문장을 덧붙이지 않는다.`,
    '네 부분 전체에 적용할 공감 기준: 사용자가 실제로 밝힌 구체적인 부담을 인정한다. 걱정을 그만두라고 하거나 걱정할 필요가 없다고 단정하지 않고, 성공·호전·자신감의 결과를 보장하지 않는다. 대신 사용자가 지금 선택해 시도할 수 있는 행동과 그 행동에서 직접 확인할 수 있는 점을 연결한다. 감정이 나아져야만 행동할 수 있다는 조건을 만들지 않는다.',
    '도움의 초점: 사용자가 연습할 활동 자체의 작은 동작을 요청하면 그 활동의 구체적인 대상과 동작을 제안한다. 일정·이동 준비나 목표를 정하라는 말로 바꾸지 않는다. 이유는 지금 관찰할 수 있는 과정에 두고 미래 성과를 단정하지 않는다. 네 부분 모두 기존 운영자 말투와 길이를 유지한다.',
  ].join('\n');
  const assembled = compileSlimContext(persona, personaHash, items, budget - [...suffix].length, capabilities);
  const text = assembled.text + suffix;
  return { ...assembled, text, contextChars: [...text].length, contextBudget: budget };
}

/** The schema remains four unconstrained strings; all changes are instructions. */
export function anchoredContract(persona, capabilities, prompt = '') {
  const format = structuredClone(slimContract(persona, capabilities, prompt));
  const fields = format.schema.properties.reply.properties;
  fields.identity.description += ` 이 필드와 나머지 답변에서 응답자 자신의 이름은 오직 운영자 설정 ${JSON.stringify(persona.name)}이다. 사용자가 제안한 호칭이나 이전 답변의 다른 이름을 새 자기 이름으로 채택하지 않는다. 사용자와 도우미의 이름을 혼동하지 않는다. 직접 인용한 문장은 자기소개와 구분한다.`;
  fields.acknowledgement.description += ' 구체적인 부담을 인정한 다음 걱정을 취소하거나 성공을 장담하는 말로 뒤집지 않는다. 사용자가 감정을 바꾸도록 요구하지 않는다.';
  fields.next_step.description += ' 요청한 활동 자체에 해당하는 동작을 고르고 사용자가 그 동작에서 직접 관찰할 수 있는 목적을 설명한다. 그 결과로 반드시 잘하게 되거나 자신감이 생길 것이라고 약속하지 않는다.';
  return format;
}

// Reuse the exact v10 format validator and byte-preserving projection.
export const decodeAnchoredReply = decodeSlimReply;
