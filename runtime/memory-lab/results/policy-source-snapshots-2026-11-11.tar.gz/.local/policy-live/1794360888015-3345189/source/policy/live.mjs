#!/usr/bin/env node
import assert from 'node:assert/strict';
import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { join, dirname, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { inside, clean, secretFile } from '../../clova/common.ts';
import { PolicySession, projectRoot as root } from './session.mjs';

const here = dirname(fileURLToPath(import.meta.url));
const args = process.argv.slice(2);
const option = (name, fallback) => args.includes(name) ? args[args.indexOf(name) + 1] : fallback;
assert.ok(args.includes('--live'), 'Pass --live to make real model API calls');
assert.ok(args.every((a, i) => a === '--live' || ['--output', '--plan'].includes(a) || ['--output', '--plan'].includes(args[i - 1])), 'Unknown option');
secretFile(process.env.CLOVA_API_KEY_FILE);
if (process.env.CLOVA_BASE_URL) assert.equal(new URL(process.env.CLOVA_BASE_URL).origin, 'https://clovastudio.stream.ntruss.com');
const hash = path => createHash('sha256').update(readFileSync(path)).digest('hex');
const planPath = inside(root, relative(root, resolve(option('--plan', join(here, 'eval-plan.json'))))), plan = JSON.parse(readFileSync(planPath, 'utf8'));
const output = inside(root, relative(root, resolve(option('--output', join(here, '../results/policy-live-2026-11-11.json')))));
assert.ok(!existsSync(output), 'Preserve old evidence: choose a new output path');
const runDir = inside(root, `.local/policy-live/${Date.now()}-${process.pid}`);
mkdirSync(runDir, { recursive: true, mode: 0o700 });
const prompts = plan.steps.filter(s => s.op === 'prompt').length;
assert.equal(prompts * plan.personas.length * plan.variants.length, plan.budget.draftCalls);
const callLimit = plan.budget.maxPlannedTotalCalls;
assert.ok(Number.isSafeInteger(callLimit) && callLimit >= 1 && callLimit <= 60); assert.equal(plan.generation.maxTokens, 1024);
assert.equal(plan.model, 'clova:HCX-005');
assert.ok(plan.variants.every(v => ['baseline', 'compiled', 'guarded', 'compiled-v2', 'guarded-v2', 'voiced-v3'].includes(v)));
assert.ok(plan.budget.draftCalls + plan.variants.filter(v => v.startsWith('guarded') || v === 'voiced-v3').length * plan.personas.length * prompts <= callLimit);
const report = { schemaVersion: 1, runId: plan.id, startedAt: new Date().toISOString(), model: plan.model, framework: 'pi', synthetic: false, provider: 'NAVER CLOVA Studio official HTTPS', planSha256: hash(planPath), plan, rawArtifacts: relative(root, runDir), sourceSnapshots: {}, callLimit, modelRequests: 0, responses: 0, knownUsage: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 }, usageComplete: true, cost: null, groups: [], executionCompleted: false };
for (const name of ['policy/live.mjs', 'policy/session.mjs', 'policy/compiler.mjs', 'policy/guard.mjs', 'policy/guard-v2.mjs', 'policy/compiler-v2.mjs', 'policy/register.mjs', 'policy/voice.mjs', relative(resolve(here, '..'), planPath), 'pi/cli.mjs', 'pi/store.mjs', 'pi/provider-bridge.mjs', '../clova/provider.ts']) {
  const source = resolve(here, '..', name), target = join(runDir, 'source', name.replace('../', 'parent/'));
  mkdirSync(dirname(target), { recursive: true }); writeFileSync(target, readFileSync(source));
  report.sourceSnapshots[name] = { sha256: hash(source), path: relative(root, target) };
}
const save = () => { mkdirSync(dirname(output), { recursive: true }); writeFileSync(output, JSON.stringify(clean(report), null, 2) + '\n', { mode: 0o600 }); };
let lastStarted = 0, fatal;
const pause = ms => new Promise(r => setTimeout(r, ms));
const onEvent = event => {
  if (event.t === 'model_context') {
    report.modelRequests++; lastStarted = Date.parse(event.data.callStartedAt);
  }
  if (event.t === 'model_response') {
    if (event.data.ok) report.responses++;
    if (event.data.usage) for (const key of Object.keys(report.knownUsage)) report.knownUsage[key] += event.data.usage[key] ?? 0;
    else report.usageComplete = false;
  }
};
try {
  for (const persona of plan.personas) for (const variant of plan.executionOrder[persona.key]) {
    const dir = join(runDir, persona.key, variant); mkdirSync(dir, { recursive: true });
    const fixture = join(dir, 'persona.json'); writeFileSync(fixture, JSON.stringify(persona.persona, null, 2) + '\n');
    const group = { personaKey: persona.key, variant, personaHash: hash(fixture), steps: [], operations: [], processes: [], completed: false };
    report.groups.push(group); save();
    let session, processIndex = 0;
    const start = async () => {
      // Source edits during a trial invalidate the comparison; abort before another call.
      for (const [name, snapshot] of Object.entries(report.sourceSnapshots)) assert.equal(hash(resolve(here, '..', name)), snapshot.sha256, 'Source changed during run');
      session = new PolicySession({ dir: join(dir, `process-${++processIndex}`), store: join(dir, 'memory.sqlite'), persona: fixture, policy: variant, minCallIntervalMs: plan.budget.minCallIntervalMs, onEvent });
      group.processes.push({ artifactDir: relative(root, session.dir) });
      await session.ready(); assert.equal(session.info.syntheticOnly, false); assert.equal(session.info.model, plan.model);
    };
    const close = async () => { if (session) { try { await session.close(); } finally { group.processes.at(-1).cleanup = session.cleanup ?? null; save(); } } };
    try {
      await start();
      for (const step of plan.steps) {
        if (step.op === 'restart') { await close(); await start(); group.operations.push({ op: 'restart', history: 'empty; same persisted scoped store' }); continue; }
        if (step.op !== 'prompt') {
          const command = step.op === 'remember' ? { op: 'remember', memory: step.memory } : { op: 'observe', turnId: step.turnId, text: step.text };
          const events = await session.command(command);
          assert.ok(!events.some(e => e.t === 'error'), 'Memory operation failed');
          if (step.op === 'remember') assert.ok(events.some(e => e.t === 'memory_result' && e.data.ok), 'Memory was not committed');
          group.operations.push({ ...command, events, history: step.op === 'remember' ? 'cleared after approved non-idempotent memory commit' : 'unchanged' }); save(); continue;
        }
        const reserved = (variant.startsWith('guarded') || variant === 'voiced-v3') ? 2 : 1;
        assert.ok(report.modelRequests + reserved <= callLimit, 'Insufficient bounded call budget');
        const recall = await session.command({ op: 'recall' });
        const activeMemorySnapshot = recall.find(e => e.t === 'memories')?.data.items;
        assert.ok(activeMemorySnapshot);
        await pause(Math.max(0, lastStarted + plan.budget.minCallIntervalMs - Date.now()));
        const events = await session.command({ op: 'prompt', text: step.text });
        const end = events.find(e => e.t === 'turn_end')?.data;
        const attempts = events.filter(e => e.t === 'model_context').map(e => {
          const response = events.find(r => r.t === 'model_response' && r.data.requestIndex === e.data.requestIndex);
          return { context: e.data, response: response?.data ?? null, startedAt: e.ts, finishedAt: response?.ts ?? null, latencyMs: response ? Date.parse(response.ts) - Date.parse(e.ts) : null };
        });
        const deliveredText = events.filter(e => e.t === 'text').map(e => e.data.text).join('');
        const row = { postProcessing: variant === 'voiced-v3' ? 'fresh-context-always' : 'same-history-if-violation', scenarioId: step.id, prompt: step.text, scoredAxes: step.scoredAxes, activeMemorySnapshot, draftText: attempts[0]?.response?.content ?? null, repairText: attempts[1]?.response?.content ?? null, deliveredText: deliveredText || null, deliveryStatus: end?.ok ? 'delivered' : end?.endReason === 'persona_violation' ? 'blocked' : 'error', policyChecks: events.filter(e => e.t === 'policy_check').map(e => e.data), apiAttemptLog: attempts, turnEnd: end ?? null, errors: events.filter(e => e.t === 'error').map(e => e.data), historyAfter: end?.ok ? 'accepted conversation; repair internals removed' : 'cleared by worker' };
        group.steps.push(row); save();
        assert.ok(end && attempts.length <= reserved, 'Unexpected model call count');
        for (const attempt of attempts) {
          assert.equal(attempt.context.omittedCount, 0, 'Context budget omitted a memory');
          assert.equal(attempt.context.selectedCount, activeMemorySnapshot.length, 'Conditions differ in selected memories');
        }
        if (deliveredText) assert.equal(deliveredText, attempts.at(-1)?.response?.content, 'Delivered text must be exact model output');
        assert.ok(events.every(e => !['tool_call', 'tool_result', 'approval'].includes(e.t)), 'Dialogue invoked a tool');
        if (end.endReason !== 'completed' && end.endReason !== 'persona_violation') throw new Error('Recorded model/operational failure: ' + end.endReason);
        process.stdout.write(JSON.stringify({ persona: persona.key, variant, scenario: step.id, delivery: row.deliveryStatus, requests: report.modelRequests, repairs: end.correctionAttempts }) + '\n');
      }
      group.completed = true;
    } finally { await close(); }
  }
  report.executionCompleted = true;
} catch (error) { fatal = error; report.error = String(clean(error.message)); }
finally {
  report.finishedAt = new Date().toISOString();
  const rows = report.groups.flatMap(g => g.steps);
  report.summary = { attemptedPrompts: rows.length, delivered: rows.filter(r => r.deliveryStatus === 'delivered').length, blocked: rows.filter(r => r.deliveryStatus === 'blocked').length, errors: rows.filter(r => r.deliveryStatus === 'error').length, repairs: rows.reduce((s, r) => s + (r.turnEnd?.correctionAttempts ?? 0), 0) };
  save(); process.stdout.write(JSON.stringify({ output: relative(root, output), executionCompleted: report.executionCompleted, modelRequests: report.modelRequests, ...report.summary }) + '\n');
}
if (fatal) process.exitCode = 1;
