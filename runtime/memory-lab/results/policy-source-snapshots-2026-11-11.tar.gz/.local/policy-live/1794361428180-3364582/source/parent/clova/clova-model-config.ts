import { Fault } from './common.ts';

/**
 * Native CLOVA v3 generation fields only. No credentials, transport or I/O.
 * Official references checked 2026-11-11:
 * https://api.ncloud-docs.com/docs/clovastudio-chatcompletionsv3
 * https://api.ncloud-docs.com/docs/clovastudio-chatcompletionsv3-thinking
 *
 * HCX-007 requires maxCompletionTokens (not maxTokens). thinking.effort defaults
 * to low at the service, so explicitly disable it for the existing non-thinking
 * comparison and tool-call path. Both APIs document temperature 0..1.
 *
 * The lab's existing 1..2048 limit is intentionally preserved, even though the
 * remote models support larger outputs. This helper does not enlarge the budget
 * or infer that any other syntactically valid model exists at the provider.
 */
export type ClovaGenerationConfig =
  | { maxTokens: number; temperature: 0; maxCompletionTokens?: never; thinking?: never }
  | { maxCompletionTokens: number; temperature: 0; thinking: { effort: 'none' }; maxTokens?: never };

export function clovaGenerationConfig(
  model: string,
  generation: { maxTokens?: number } = {},
  toolCount = 0,
): ClovaGenerationConfig {
  if (typeof model !== 'string' || !/^(?:clova:)?[A-Za-z0-9_-]+$/.test(model)) {
    throw new Fault('configuration', 'native CLOVA model must be a model name or clova:<model>');
  }
  if (!generation || typeof generation !== 'object' || Array.isArray(generation)) {
    throw new Fault('invalid_argument', 'generation must be an object');
  }
  const maxTokens = generation.maxTokens ?? 2048;
  if (!Number.isInteger(maxTokens) || maxTokens < 1 || maxTokens > 2048) {
    throw new Fault('invalid_argument', 'maxTokens must be an integer from 1 to 2048');
  }
  if (!Number.isInteger(toolCount) || toolCount < 0) {
    throw new Fault('invalid_argument', 'toolCount must be a nonnegative integer');
  }
  if (toolCount && maxTokens < 1024) {
    throw new Fault('invalid_argument', 'CLOVA function calling requires maxTokens of at least 1024');
  }
  const modelName = model.startsWith('clova:') ? model.slice(6) : model;
  if (modelName === 'HCX-007') {
    return { maxCompletionTokens: maxTokens, temperature: 0, thinking: { effort: 'none' } };
  }
  return { maxTokens, temperature: 0 };
}
